# Android device tree for Infinix Infinix X6812 (Infinix-X6812)

```
#
# Copyright (C) 2023 The LineageOS Project
#
# SPDX-License-Identifier: Apache-2.0
#
```
